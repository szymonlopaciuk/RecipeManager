#!/bin/sh
cd ../MacOS/
otool -L recipe | grep -vE '(/usr/lib)|(/System/Library)' | egrep '^\t(.*)\/(.*)\ \(.*\)$' | sed -E 's/    (.*)\/(.*)\ \(.*\)/cp \1\/\2 \2 ; install_name_tool -change \1\/\2 @executable_path\/\2 recipe/g' | sh
